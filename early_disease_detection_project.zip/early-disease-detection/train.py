from app.models import MultiModalClassifier
from app.preprocessing import load_data
import torch
import torch.nn as nn
import torch.optim as optim

X_fused, y = load_data()

model = MultiModalClassifier(input_dim=X_fused.shape[1])
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

for epoch in range(20):
    outputs = model(X_fused)
    loss = criterion(outputs, y)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch + 1}: Loss = {loss.item():.4f}")

torch.save(model.state_dict(), "model.pth")
