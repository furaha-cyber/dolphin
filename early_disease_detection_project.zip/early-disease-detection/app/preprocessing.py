import torch
from transformers import BertTokenizer, BertModel
from torchvision import models, transforms
from PIL import Image

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
bert = BertModel.from_pretrained('bert-base-uncased')

resnet = models.resnet18(pretrained=True)
resnet.fc = torch.nn.Identity()

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

def extract_text_features(texts):
    inputs = tokenizer(texts, padding=True, truncation=True, return_tensors="pt")
    with torch.no_grad():
        outputs = bert(**inputs)
    return outputs.pooler_output

def extract_image_features(image_paths):
    features = []
    for path in image_paths:
        img = Image.open(path).convert('RGB')
        img_tensor = transform(img).unsqueeze(0)
        with torch.no_grad():
            feat = resnet(img_tensor)
        features.append(feat.squeeze(0))
    return torch.stack(features)

def load_data():
    import pandas as pd
    df = pd.DataFrame({
        'heart_rate': [88, 95, 110],
        'temperature': [36.6, 38.2, 39.0],
        'oxygen_saturation': [98, 92, 85],
        'label': [0, 1, 1]
    })
    symptoms = ["No symptoms", "Cough and fatigue", "High fever, difficulty breathing"]
    images = ["data/xray1.jpg", "data/xray2.jpg", "data/xray3.jpg"]

    X_tabular = torch.tensor(df[['heart_rate', 'temperature', 'oxygen_saturation']].values).float()
    y = torch.tensor(df['label'].values).long()

    X_text = extract_text_features(symptoms)
    X_image = extract_image_features(images)

    X_fused = torch.cat((X_tabular, X_text, X_image), dim=1)
    return X_fused, y
