import torch
from app.models import MultiModalClassifier
from app.preprocessing import extract_text_features, extract_image_features, transform
from PIL import Image

def predict_disease(symptom_text, image_file):
    model = MultiModalClassifier(input_dim=1283)
    model.load_state_dict(torch.load("model.pth"))
    model.eval()

    X_text = extract_text_features([symptom_text])
    image = Image.open(image_file).convert('RGB')
    X_image = extract_image_features([image_file.name])
    X_tabular = torch.tensor([[90.0, 37.0, 95.0]])  # Dummy vitals

    X_fused = torch.cat((X_tabular, X_text, X_image), dim=1)
    with torch.no_grad():
        output = model(X_fused)
    prediction = torch.argmax(output, dim=1).item()
    return "Sick" if prediction == 1 else "Healthy"
