import torch
import torch.nn as nn

class MultiModalClassifier(nn.Module):
    def __init__(self, input_dim):
        super(MultiModalClassifier, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 2)
        )

    def forward(self, x):
        return self.model(x)
