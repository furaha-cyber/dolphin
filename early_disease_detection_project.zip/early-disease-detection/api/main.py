from fastapi import FastAPI, UploadFile, Form
from app.inference import predict_disease

app = FastAPI()

@app.post("/predict")
async def predict(symptom_text: str = Form(...), image: UploadFile = None):
    prediction = predict_disease(symptom_text, image.file)
    return {"prediction": prediction}
