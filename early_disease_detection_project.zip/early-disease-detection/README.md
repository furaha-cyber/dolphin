# AI-Powered Early Disease Detection via Multi-Modal Data Fusion

This project demonstrates early disease detection using tabular, textual, and image data combined using deep learning.

## Components
- **Multi-Modal Fusion Model** (text, tabular, image)
- **API** for prediction
- **Streamlit Dashboard**

## Setup
```bash
pip install -r requirements.txt
```

## Run
Train:
```bash
python train.py
```

Streamlit App:
```bash
streamlit run dashboard/app.py
```

FastAPI:
```bash
uvicorn api.main:app --reload
```
