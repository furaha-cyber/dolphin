import streamlit as st
from app.inference import predict_disease

st.title("AI-Powered Early Disease Detection")

symptoms = st.text_input("Describe your symptoms")
image = st.file_uploader("Upload chest X-ray", type=["jpg", "jpeg", "png"])

if st.button("Predict"):
    if symptoms and image:
        prediction = predict_disease(symptoms, image)
        st.success(f"Prediction: {prediction}")
    else:
        st.error("Please provide both symptoms and an image.")
